#ifndef STAN_MEMORY_HPP
#define STAN_MEMORY_HPP

#include "stan/memory/stack_alloc.hpp"

#endif

