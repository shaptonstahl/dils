sigmasq <- 0.05
mu <- c(5, 2, -6)
theta <- structure(
                   c(5, 2, -6, 
                     5, 2, -6, 
                     5, 2, -6, 
                     5, 2, -6, 
                     5, 2, -6), 
                   .Dim = c(5, 3))
sigma2 <- structure(
                    c(1, 0, 0,
                      0, 1, 0,
                      0, 0, 1),
                    .Dim = c(3,3))
