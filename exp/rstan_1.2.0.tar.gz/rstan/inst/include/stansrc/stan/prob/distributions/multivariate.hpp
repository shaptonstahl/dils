#ifndef __STAN__PROB__DISTRIBUTIONS__MULTIVARIATE_HPP__
#define __STAN__PROB__DISTRIBUTIONS__MULTIVARIATE_HPP__

#include <stan/prob/distributions/multivariate/continuous.hpp>
#include <stan/prob/distributions/multivariate/discrete.hpp>

#endif
