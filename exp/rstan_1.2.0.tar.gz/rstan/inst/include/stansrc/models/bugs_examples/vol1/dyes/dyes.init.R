theta <- 1500
tau_within <- 1
tau_between <- 1
mu <- c(1500, 1500, 1500, 1500, 1500, 1500)