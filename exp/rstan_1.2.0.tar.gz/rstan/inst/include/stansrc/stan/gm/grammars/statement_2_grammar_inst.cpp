#include <stan/gm/grammars/statement_2_grammar_def.hpp>
#include <stan/gm/grammars/iterator_typedefs.hpp>

namespace stan {
  namespace gm {
    template struct statement_2_grammar<pos_iterator_t>;
  }
}
