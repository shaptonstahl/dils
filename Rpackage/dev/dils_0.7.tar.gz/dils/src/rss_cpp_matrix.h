#ifndef _dils_RSS_CPP_MATRIX_H
#define _dils_RSS_CPP_MATRIX_H

#include <Rcpp.h>

RcppExport SEXP rss_cpp_matrix(SEXP xadj, SEXP radius);

#endif
