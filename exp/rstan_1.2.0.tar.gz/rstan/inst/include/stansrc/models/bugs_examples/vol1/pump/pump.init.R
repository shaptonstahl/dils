alpha <- 1
beta <- 1
theta <- c(1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
