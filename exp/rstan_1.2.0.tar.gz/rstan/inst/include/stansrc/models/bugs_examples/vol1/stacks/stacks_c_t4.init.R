beta0 <- 10
beta <- c(0, 0, 0)
sigmasq <- 10
phi <- 0.316