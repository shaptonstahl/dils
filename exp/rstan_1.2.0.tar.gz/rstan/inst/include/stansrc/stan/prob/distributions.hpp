#ifndef __STAN__PROB__DISTRIBUTIONS_HPP__
#define __STAN__PROB__DISTRIBUTIONS_HPP__

#include <stan/prob/distributions/univariate.hpp>
#include <stan/prob/distributions/multivariate.hpp>

#endif
