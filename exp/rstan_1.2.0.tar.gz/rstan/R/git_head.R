git_head <- function() "1cde932d15a348df17e9dafce17a79299b9d8a2d"
