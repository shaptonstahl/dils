alpha <- -1
beta <- -1
