#ifndef __STAN__PROB__DISTRIBUTIONS__UNIVARIATE_HPP__
#define __STAN__PROB__DISTRIBUTIONS__UNIVARIATE_HPP__

#include <stan/prob/distributions/univariate/continuous.hpp>
#include <stan/prob/distributions/univariate/discrete.hpp>

#endif
