#ifndef __STAN__PROB__DISTRIBUTIONS__MULTIVARIATE__DISCRETE_HPP__
#define __STAN__PROB__DISTRIBUTIONS__MULTIVARIATE__DISCRETE_HPP__

#include <stan/prob/distributions/multivariate/discrete/categorical.hpp>
#include <stan/prob/distributions/multivariate/discrete/multinomial.hpp>
#endif
