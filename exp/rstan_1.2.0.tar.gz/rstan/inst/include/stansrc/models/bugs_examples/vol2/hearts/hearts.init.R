alpha <- 0
delta <- 0

