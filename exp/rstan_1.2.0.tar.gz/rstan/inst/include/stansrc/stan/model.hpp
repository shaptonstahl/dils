#ifndef STAN_MODEL_HPP
#define STAN_MODEL_HPP

#include "stan/model/prob_grad.hpp"
#include "stan/model/prob_grad_ad.hpp"

#endif
