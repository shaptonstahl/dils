alpha <- 1
beta <- 1
tau <- 1
lambda <- 0.9