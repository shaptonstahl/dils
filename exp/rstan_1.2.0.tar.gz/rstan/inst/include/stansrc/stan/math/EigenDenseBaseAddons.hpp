typedef typename internal::traits<Derived>::Index size_type; 
typedef typename internal::traits<Derived>::Scalar value_type;
