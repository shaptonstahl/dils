#ifndef STAN_GM_HPP
#define STAN_GM_HPP

#include <stan/gm/ast.hpp>
#include <stan/gm/command.hpp>

#endif
