#ifndef _dils_RELATION_STRENGTH_SIMILARITY_H
#define _dils_RELATION_STRENGTH_SIMILARITY_H

#include <Rcpp.h>

RcppExport SEXP relation_strength_similarity(SEXP xadj, SEXP v1, SEXP v2, SEXP radius) ;

#endif
