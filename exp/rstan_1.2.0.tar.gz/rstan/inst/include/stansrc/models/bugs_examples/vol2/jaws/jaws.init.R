beta0 <- 40
beta1 <- 1
Sigma <-
structure(c(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), .Dim = c(4, 
4))
