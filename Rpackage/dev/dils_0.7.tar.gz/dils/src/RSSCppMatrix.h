#ifndef _dils_RSSCPPMATRIX_H
#define _dils_RSSCPPMATRIX_H

#include <Rcpp.h>

RcppExport SEXP RSSCppMatrix(SEXP xadj, SEXP radius) ;

#endif
